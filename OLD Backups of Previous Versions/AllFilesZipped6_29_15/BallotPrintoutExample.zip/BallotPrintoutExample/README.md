# StarVoteBallotImage
(Mainly) HTML and CSS code for creating the ballot print-out
